                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  <!DOCTYPE html>
<html>
    <head>
  		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta name="google-site-verification" content="j0jQRVjco8KfkXyHMm_cBPzJRnpVhReCPc9DtdAjjIA" />
      <meta name="facebook-domain-verification" content="zc05c91ouubgtpq1e6yfek9axbe8z3" />
      <meta name="author" content="riseinfraventures.com" />
      <meta name="copyright" content="RISE Infraventures Limited" />
      <meta name="geo.region" content="IN" />
      <meta name="geo.placename" content="Gurgaon" />
      <meta name="geo.position" content="28.4159963,77.0994191" /> 
      <meta name="ICBM" content="28.4159963,77.0994191" />
      <meta content="FOLLOW, INDEX, ALL" name="robots" />
      <meta content="english" name="language" />
      <meta content="Global" name="distribution" />
      <meta content="yes" name="ALLOW-SEARCH" />
      <meta content="all" name="AUDIENCE" />
      <meta content="index, follow" name="YahooSeeker" />
      <meta content="index, follow" name="msnbot" />
      <meta content="index, follow" name="googlebot" />
      <meta name="google-site-verification" content="ujhKR4-xbi3iaCdUn-Yo-W7KDKuxcudLxoZhiaQIXao" />
      <meta name="msvalidate.01" content="69AE5C1D5CD9C18D41167662D2528DE6" />
      <meta property="og:type" content="website" />
      <meta property="og:locale" content="en_US" />
      <meta property="og:site_name" content="riseinfraventures.com" />
      <meta id="titleOG" property="og:title" content="Commercial and Residential Projects in Gurgaon | RISE Infraventures" />

                  <meta
          id="descriptionOG"
          property="og:description"
          content="RISE Infraventures is the most experienced and renowned real estate consultant and property agent for commercial and residential projects in Gurgaon. RISE Infraventures coming with a vision to help people find the right investment opportunity in the fast-paced property market of India."
      />
      <meta id="urlOG" property="og:url" content="index.php" />
      <meta id="imageMetaOG" property="og:image" name="image" content="asset/images/commercial-and-residential-projects.png" />
      <meta id="titleGoogle" itemprop="name" content="Commercial and Residential Projects in Gurgaon | RISE Infraventures" />
      <meta
          id="descriptionGoogle"
          itemprop="description"
          content="RISE Infraventures is the most experienced and renowned real estate consultant and property agent for commercial and residential projects in Gurgaon. RISE Infraventures coming with a vision to help people find the right investment opportunity in the fast-paced property market of India."
      />
      <meta id="imageMetaGoogle" itemprop="image" content="asset/images/commercial-and-residential-projects.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta id="titleTwitter" name="twitter:title" content="Commercial and Residential Projects in Gurgaon | RISE Infraventures" />
      <meta
          id="descriptiontwitter"
          name="twitter:description"
          content="RISE Infraventures is the most experienced and renowned real estate consultant and property agent for commercial and residential projects in Gurgaon. RISE Infraventures coming with a vision to help people find the right investment opportunity in the fast-paced property market of India."
      />
      <meta id="imageMetaTwitter" name="twitter:image" content="asset/images/commercial-and-residential-projects.png" />
      <title>
          Commercial and Residential Projects in Gurgaon | RISE Infraventures
      </title>
      <meta
          id="description1"
          name="description"
          content="RISE Infraventures is the most experienced and renowned real estate consultant and property agent for commercial and residential projects in Gurgaon. RISE Infraventures coming with a vision to help people find the right investment opportunity in the fast-paced property market of India."
      />
      <meta
          id="keywords1"
          name="keywords"
          content="real estate companies in gurgaon, real estate consultants in gurgaon, commercial projects in gurgaon, commercial property in gurgaon, residential property in gurgaon, residential projects in gurgaon, affordable housing projects in gurgaon"
      />
      <meta id="url1" name="url" content="index.php" />
      <link rel="shortcut icon" href="https://riseinfraventures.com/assets/front/images/favicon.png" />
      <link href="https://riseinfraventures.com/assets/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
      <link href="https://riseinfraventures.com/assets/front/css/owl.carousel.min.css" rel="stylesheet" />
      <link href="https://riseinfraventures.com/assets/front/css/owl.theme.default.min.css" rel="stylesheet" />
      <link href="https://riseinfraventures.com/assets/front/css/jquery.toast.min.css" rel="stylesheet" />
      <link href="https://riseinfraventures.com/assets/front/css/scroll_bar.css" rel="stylesheet" />
      <link href="https://riseinfraventures.com/assets/front/css/style.css" rel="stylesheet" />
      <link href="https://riseinfraventures.com/assets/front/css/custom.css" rel="stylesheet" />
      <style type="text/css">
        .modal1_1 {
          position: fixed;
          height: 100%;
          width: 100%;
          right: 0;
          top: 0;
          background-color: #efe4e4a1;
          filter: alpha(opacity=60);
          opacity: 1;
          -moz-opacity: 0.8;
          bottom: 0;
        }
        .center1_1 {
          z-index: 1000;
          padding: 10px;
          width: 220px;
          border-radius: 10px;
          filter: alpha(opacity=100);
          opacity: 1;
          -moz-opacity: 1;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
        }
        .center1_1 p {
          display: none;
          font-size: 20px;
          line-height: 28px;
          margin-top: 18px;
          text-transform: uppercase;
          text-align: center;
        }
        .center1_1 img {
          width: 100%;
        }
        select {
          outline: none!important;
          border: none!important;
          border-bottom: 1px solid!important;
          width: 100%;
          font-size: 12px;
          color: #666666;
          font-weight: 500;
          padding: 7px 0px;
          width: 100%;
          cursor: pointer;
        }
        select {
          -webkit-appearance: auto!important;
        }
        
        .round-img-c {
    box-shadow: 2px 2px 20px 0 #808080b8;
    border-radius: 89px;
    width: 130px;
    margin-top: 12px;
    margin-bottom: 20px;
    transition: .7s;
    padding: 5px;
    border: 1px solid #c4962a;
    background: #fff
}

.serve-pd{
    box-shadow: 4px 4px 20px 0 #808080b8;
     border-radius: 20px;
}


     .whatsapp_float {
    position: fixed;
    bottom: 70px;
    right: 20px;
    /* left: 18px; */
    z-index: 9999 !important;
     width: 70px;
}


.popup {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 1000;
  display: none; /* Hide the popup initially */
  width: 80%; /* Default width, can be adjusted */
  max-width: 400px; /* Max width for larger screens */
  background-color: white;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  overflow: hidden;
}

.popup-inner {
  padding: 20px;
  text-align: center;
}

.popup img {
  width: 100%; /* Make the image responsive */
  height: auto;
  display: block;
  /*margin: 0 auto 20px;*/
}

.popup .close {
  position: absolute;
  top: -16px;
  right: 0px;
  cursor: pointer;
  font-size: 32px;
  color: #000;
}

.responsive {
  width: 100%;
  /*max-width: 100%;*/
  height: auto;
}

@media (max-width: 768px) {
  .popup {
    width: 90%;
  }
}

@media (max-width: 480px) {
  .popup {
    width: 95%;
  }
}

/* Display the popup when it is active */
.popup.active {
  display: block;
}
      </style>
      
      
      <script id="mainlib" src="https://riseinfraventures.com/assets/front/js/jquery.min.js"></script>
      <script defer src="https://riseinfraventures.com/assets/front/js/jquery-ui.js"></script>
      <script type="text/javascript">
        var baseURL = "https://riseinfraventures.com/";
      </script>
      
      <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WF5NDM4');</script>
<!-- End Google Tag Manager -->

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-KHEP9EMEBL"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-KHEP9EMEBL');
</script>

      
      
    <!--  <script -->
    <!--  type="text/javascript"-->
    <!--  src="https://d3mkw6s8thqya7.cloudfront.net/integration-plugin.js"-->
    <!--  id="aisensy-wa-widget"-->
    <!--  widget-id="dee1n6">-->
    <!--</script>-->
  
  </head>
	<body>
	    
	    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WF5NDM4"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
	    
	<header>
      <nav>
	    	<div class="clmd2">
	    	
          <a href="javascript:loadPopup();" class="QickEnqSwn EnqPhone blnkclr">Quick Inquiry</a>
	    	</div>
	      <div class="clmd8">
	        <div class="LgonSevr">
	          <a href="https://riseinfraventures.com/" class="Logo">
	          	<img src="https://riseinfraventures.com/assets/front/images/logo.png" data-name="logo-inverse" alt="riseinfraventures" /> 
	         	</a>
	        </div>
	        <div class="Strymnvr">
	          <div class="ClsMenuBtn"></div>
	          <ul>
	            <li style="position:relative;" class="dropdown">
                <a href="#">Our Story <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                <ul class="sub-menu">
                  <li>
                    <a  href="https://riseinfraventures.com/about-us#rise">Rise</a>
                  </li>
                  <!--<li>-->
                  <!--  <a target="_blank" href="https://riseinfraventures.com/about-us#leaders">Leaders</a>-->
                  <!--</li>-->
                  <li>
                    <a  href="https://riseinfraventures.com/about-us#vision">Mission & Vision</a>
                  </li>
                </ul>
              </li>
              <li style="position:relative;" class="dropdown">
                <a href="#">Services <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                <ul class="sub-menu">
                  <li>
                    <a  href="https://riseinfraventures.com/category/commercial">Commercial</a>
                  </li>
                  <li>
                    <a  href="https://riseinfraventures.com/category/residential">Residential</a>
                  </li>
                  
                   <li><a  href="https://riseinfraventures.com/land">Land</a></li>
                   
                   <li><a  href="https://riseinfraventures.com/it">IT Services</a></li>
                 
                </ul>
                
                 
              </li>
	            <li style="position: relative;" class="dropdown">
                <a href="#">Cities <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                <ul class="sub-menu">
                                      <li>
                      <a  href="https://riseinfraventures.com/city/delhi">Delhi</a>
                    </li>
                                      <li>
                      <a  href="https://riseinfraventures.com/city/gurgaon">Gurgaon</a>
                    </li>
                                      <li>
                      <a  href="https://riseinfraventures.com/city/mumbai">Mumbai</a>
                    </li>
                                  </ul>
              </li>
              <li style="position:relative;" class="dropdown">
                <a href="#">News Room <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                <ul class="sub-menu">
                    
                     <li>
                    <a  href="https://riseinfraventures.com/news-room/awards">Awards</a>
                  </li>
                  <li>
                    <a  href="https://riseinfraventures.com/news-room/pr-activities">PR Activities</a>
                  </li>
                 
                  <li>
                    <a  href="https://riseinfraventures.com/news-room/events">Events</a>
                  </li>
                  <li>
                    <a  href="https://riseinfraventures.com/news-room/csr-activities">CSR Activities</a>
                  </li>
                  <li>
                    <a  href="https://riseinfraventures.com/news-room/blogs">Blogs</a>
                  </li>
                </ul>
              </li>
              <li><a target="_blank" href="https://rnrbyriseinfra.com">Research & Reports</a></li>
              
              <li><a  href="https://riseinfraventures.com/career">Careers</a></li>
              
              
              <li><a  href="https://riseinfraventures.com/contact-us">Contact</a></li>
	          </ul>
	        </div>
	      </div>
	    <div class="clmd4">
	      <div class="MnvrSwnHdr">
	        <div class="Qickengre EnqPhone" data-tbicn="1">
            <a href="javascript:loadPopup();" class="blnkclr">Quick Inquiry</a>
          </div>
	        <div class="TolFreNum"><a href="tel:1800 547 77 999"> 1800 547 77 999 </a></div>
	        <div class="SrchMnvr">
	          <div id="pnlSearchText" onkeypress="javascript:return">
              <form action="https://riseinfraventures.com/search-projects" method="post" id="header-search">
  	            <div class="SrcMnvrNv">
  	              <div class="Srvr">
  	                <input name="keyword" type="text" class="FrmmnSn autosuggest1" />
  	                <label>Search</label>
  	                <img class="clsemn" src="https://riseinfraventures.com/assets/front/icon/closeblck.png" alt="real estate" />
  	              </div>
  	              <div id="searchbx"></div>
  	              <div class="ClmnVrSwn">
                    <!-- onclick="return headerFormSubmit();" -->
  	               	<a href="javascript:void(0);" class="srchtxt">
                      <img src="https://riseinfraventures.com/assets/front/icon/search.png" alt="real estate gurgaon" />
                    </a>
  	                <a class="srchtxtpopup headerFormSubmit" href="javascript:void(0);">
  	                  <img src="https://riseinfraventures.com/assets/front/icon/search.png" alt="real estate gurgaon" />
  	                </a>
  	              </div>
  	            </div>
              </form>
	          </div>
	        </div>
	        <div class="Bugr-Icn open-overlay">
	          <span></span>
	          <span></span>
	          <span></span>
	        </div>
	      </div>
	    </div>
	  </nav>
	</header>

<section>
    <div class="RsrBnerSeSwnVr">
        <div class="BlgSwnMn">
            <img src="https://riseinfraventures.com/uploads/file-manager/" alt="Planning for real estate investment in upcoming summer season ">
        </div>
        <div class="BlgSwnrngVr">
            <small>1970-01-01</small>
            <h1></h1>
        </div>
    </div>
</section>
<section>
    <div class="BlgDlSwnvrMn CommonEditor">
            </div>
</section>


 <section id="ContentPlaceHolder1_PnlDisplayOnHome">
     <!--<div  class="flrPlnSwn">-->
     <!--     <h3> GALLERY</h3>-->
     <!--    </div>-->
        <div class="TtleMnSwn">
           
            <div class="DskcovrProMnVr">
                <div class="DlSlwnvrrseMn owl-carousel owl-theme">
                    <!--<div class="FtrdBldng-Sldr owl-carousel owl-theme">-->
                                        <!--</div>-->
                </div>
            </div>
        </div>
    </section>




 











<style type="text/css">
    .RlstdProMnSwvr .cl4smnvrSvr {
        width: 33.33%;
        padding: 10px;
        margin: auto;
    }
    .QickEnqBtn {
        background: #000;
        color: #fff;
        border-radius: 5px;
        border: none;
        padding: 10px 20px;
    }
    .QickEnqBtn:hover {
        background: #e1e1e1;
        color: #000;
    }
</style>

<script type="text/javascript">
    // $(document).ready(function() {
    //     $(document).click('.dwnldbrchue', function() {
    //         loadPopup();
    //     })
    // })
</script><div class="whatsapp_float">
 <a onclick="return gtag_report_conversion('https://api.whatsapp.com/send?phone=919811082984&amp;text=Hello%20Team%20Rise%20Infraventures%20Limited,%20I%20am%20interested%20in%20one%20of%20the%20projects%20listed%20on%20your%20website.%20Could%20you%20please%20connect%20with%20me?');" href='https://api.whatsapp.com/send?phone=919811082984&amp;text=Hello%20Team%20Rise%20Infraventures%20Limited,%20I%20am%20interested%20in%20one%20of%20the%20projects%20listed%20on%20your%20website.%20Could%20you%20please%20connect%20with%20me?' target="_blank"><img src="https://riseinfraventures.com/assets/front/images/wp.gif" width="50px"></a>
 </div>


<footer>
  <div class="container-fluid">
    <div class="FtrPdingIdr">
      <div class="FtrLogoSc">
       
       
      </div>
      <div class="FtrCntSecmn">

        <div class="cl12SemnFtrClmn">
          <div class="col6ftrSecmn">
             
               <img src="https://riseinfraventures.com/assets/front/images/ftrlogo.png" alt="commercial property" /><br><br>
            <ul style="width: max-content; margin-left: -48px;">
              <li>
                <a target="_blank" href="https://www.instagram.com/riseinfraventures/" title="Instagram">
                  <svg class="riseicon" aria-hidden="true" data-icon="instagram" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                    <path
                        fill="currentColor"
                        d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"
                    ></path>
                  </svg>
                </a>
              </li>
              <li>
                <a target="_blank" href="https://www.facebook.com/Riseinfraventureslimited" title="Facebook">
                  <svg class="riseicon" aria-hidden="true" data-icon="facebook" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                    <path
                        fill="currentColor"
                        d="M448 56.7v398.5c0 13.7-11.1 24.7-24.7 24.7H309.1V306.5h58.2l8.7-67.6h-67v-43.2c0-19.6 5.4-32.9 33.5-32.9h35.8v-60.5c-6.2-.8-27.4-2.7-52.2-2.7-51.6 0-87 31.5-87 89.4v49.9h-58.4v67.6h58.4V480H24.7C11.1 480 0 468.9 0 455.3V56.7C0 43.1 11.1 32 24.7 32h398.5c13.7 0 24.8 11.1 24.8 24.7z"
                    ></path>
                  </svg>
                </a>
              </li>
              <li>
                <a target="_blank" href="https://www.linkedin.com/company/riseinfraventures" title="LinkedIn">
                  <svg class="riseicon" aria-hidden="true" data-icon="linkedin" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                    <path
                        fill="currentColor"
                        d="M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.6 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z"
                    ></path>
                  </svg>
                </a>
              </li>
              <li>
                <a target="_blank" href="https://twitter.com/rise_infra" title="Twitter">
                  <svg class="riseicon" aria-hidden="true" data-icon="twitter" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                    <path
                        fill="currentColor"
                        d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"
                    ></path>
                  </svg>
                </a>
              </li>
              <li>
                <a target="_blank" href="https://www.youtube.com/channel/UCJhp0ZJqpC8-8bKg5yo4kuw" title="Youtube">
                  <svg class="riseicon" aria-hidden="true" data-icon="youtube" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" data-fa-i2svg="">
                    <path
                        fill="currentColor"
                        d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"
                    ></path>
                  </svg>
                </a>
              </li>
            </ul>
          </div>
          
           <div class="col6ftrSecmn footer-address">
            <div style="color:white;" class="">
              <h5 style="margin-top:31px;font-size:larger;text-align:left!important; color:white;">
               
                Quick Links
              </h5><br>
             
                <div style="padding: 3px;" >
               <a  href="https://riseinfraventures.com/about-us" style="color:white; padding: 7px;">About Us </a>
               </div>
                <div style="padding: 3px;">
                <a  href="https://riseinfraventures.com/projects" style="color:white; padding: 7px;">Projects </a>
              </div>
               <div style="padding: 3px;">
              <a  href="https://riseinfraventures.com/career" style="color:white; padding: 7px;">Careers</a>
              </div>
               <div style="padding: 3px;">
             <a  href="https://riseinfraventures.com/news-room/blogs" style="color:white; padding: 7px;">Blogs</a>
             </div>
              <div style="padding: 3px;">
             <a  href="https://riseinfraventures.com/privacy-policy" style="color:white; padding: 7px;">Privacy Policy</a>
             </div>
              <div style="padding: 3px;">
            <a  href="https://riseinfraventures.com/contact-us" style="color:white; padding: 7px;">Contact Us</a>
            </div>
              </div>
             
          </div>
          
          
          <div class="col6ftrSecmn footer-address">
            <div style="color:white;" class="footer-top">
              <h5 style="margin-top:31px;font-size:larger;text-align:left!important; color:white;">
              Contact Info
              </h5><br>
              
              <div class="">
                Head Office: <p>2nd Floor, Ireo Grand View Tower, Golf Course Ext Rd, Sector 58, Gurugram, Haryana 122001</p>
              </div>
              <br />
              <div class="">
                Branch Office:
                <p><span style="outline: none; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-weight: 600; font-stretch: inherit; font-size: small; line-height: inherit; font-family: Cinzel-Regular; vertical-align: baseline; color: rgb(0, 0, 0);">Dwarka Expressway :</span><span style="color: rgb(0, 0, 0); font-family: Poppins, sans-serif; font-size: small;"> 4th Floor, SCO No 8, M3M 113 Market, Sector 113, Gurugram, Haryana 122017</span><br style="outline: none; color: rgb(0, 0, 0); font-family: Poppins, sans-serif; font-size: small;"><br style="outline: none; color: rgb(0, 0, 0); font-family: Poppins, sans-serif; font-size: small;"><span style="outline: none; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-weight: 600; font-stretch: inherit; font-size: small; line-height: inherit; font-family: Cinzel-Regular; vertical-align: baseline; color: rgb(0, 0, 0);">MUMBAI:</span><span style="color: rgb(0, 0, 0); font-family: Poppins, sans-serif; font-size: small;"><br><b>Andheri: </b>Unit No. 201, Trade Avenue Premises Co-Op Soc.Ltd., Suren Road, Off Western Express<br> Highway, Andheri East Mumbai 400093<br>
<br><b>BKC:</b> 1201 - EFC | 12th Floor, B Wing, Parinee Crescenzo, G Block, Bandra Kurla Complex, Mumbai 400051</span></p>                
                
              </div>
            </div><br><br>
             <h6 class="copyright" style="color: white;font-size: small;text-align:left !important;"> ©2024 All right reserved By Rise Infraventures Ltd. </h6>
          </div>
         
        </div>
      </div>
    </div>
  </div>
  
  
  
  
</footer>
</main>



<div class="PopContntBx" id="inquiry" data-poptb="1">
  <span class="PopBxCls"> 
    <img src="https://riseinfraventures.com/assets/front/icon/closeblck.png" alt="gurgaon plots" /> 
  </span>
  <div class="PopTxtBx">
    <div class="PopCntntBx">
      <div class="PopImgBx"></div>
      <div class="PopCntctTxtBx">
        <div class="title">
          <small>Quick <span> inquiry </span></small> <em> Rise Infraventures will contact you within 24 working hours to understand your requirements. </em>
          <div class="frmBx lbl-hover1-effect">
            <div id="UpdatePanelQuickinquiry">
              <div id="pnalQuickinquiry">
                <div class="frm-body">
                  <form method="post" class="inquiry">
                    <div class="from-grp">
                      <fieldset>
                        <input name="name" type="text" class="frm-cntrl border-bottom" />
                        <label class="label-wrap">Name*</label>
                        <span class="border-bottom-animation left"></span>
                      </fieldset>
                      <fieldset>
                        <input name="email" type="text" class="frm-cntrl border-bottom" />
                        <label class="label-wrap">Email*</label>
                        <span class="border-bottom-animation left"></span>
                      </fieldset>
                    </div>
                    <div class="from-grp">
                      <fieldset class="PhoneNoSho">
                        <input name="phone" type="number" maxlength="15" class="frm-cntrl border-bottom" /> 
                        <label class="label-wrap">Phone*</label>
                        <span class="border-bottom-animation left"></span>
                      </fieldset>
                    </div>
                    <div class="from-grp">
                      <fieldset class="MessageSec">
                        <textarea name="message" rows="2" cols="20" class="frm-cntrl border-bottom"></textarea>
                        <label class="label-wrap"> Message* </label>
                        <span class="border-bottom-animation left"></span>
                      </fieldset>
                    </div>
                    <div class="BtnAlindxmn">
                      <input name="company" type="hidden" value="----"/> 
                      <a class="quick-inquiry" href="javascript:void(0);">
                        Send <img src="https://riseinfraventures.com/assets/front/icon/icnwhte.png" alt="rise infra" />
                      </a>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="MblContct-Wppr">
  <div class="Contct-Strp">
    <div class="title">
      <ul>
        <li>
          <a href="tel: 180054777999">
            <svg class="riseicon" aria-hidden="true" data-prefix="fas" data-icon="phone" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
              <path
                fill="currentColor"
                d="M493.4 24.6l-104-24c-11.3-2.6-22.9 3.3-27.5 13.9l-48 112c-4.2 9.8-1.4 21.3 6.9 28l60.6 49.6c-36 76.7-98.9 140.5-177.2 177.2l-49.6-60.6c-6.8-8.3-18.2-11.1-28-6.9l-112 48C3.9 366.5-2 378.1.6 389.4l24 104C27.1 504.2 36.7 512 48 512c256.1 0 464-207.5 464-464 0-11.2-7.7-20.9-18.6-23.4z"
              ></path>
            </svg>
            call us
          </a>
        </li>
        <li>
          <a
              href="https://api.whatsapp.com/send?phone=919811082984&amp;text=Hello%20Team%20Rise%20Infraventures%20Limited,%20I'm%20interested%20in%20one%20of%20the%20projects%20listed%20on%20your%20website.%20Could%20you%20please%20connect%20with%20me?"
              >
            <svg class="riseicon" aria-hidden="true" data-icon="whatsapp" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
              <path
                fill="currentColor"
                d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"
              ></path>
            </svg>
            whats app
          </a>
        </li>
        <li><a href="javascript:void(0);" class="EnqPhone MblIqryBtn blnkclr">Inquiry</a></li>
      </ul>
    </div>
  </div>
</div>
  
  <script defer src="https://riseinfraventures.com/assets/front/js/lazysizes.min.js"></script>
  <script defer src="https://riseinfraventures.com/assets/front/js/perfect-scrollbar.js"></script>
  <script defer src="https://riseinfraventures.com/assets/front/js/owl.carousel.js"></script>
  <script defer src="https://riseinfraventures.com/assets/front/js/jquery.toast.min.js"></script>
  <script defer src="https://riseinfraventures.com/assets/js/front.js"></script>
  <script defer src="https://riseinfraventures.com/assets/front/js/common.js"></script>
  <script src="https://riseinfraventures.com/assets/front/js/EditorJs.js"></script>
  
  <script>
    $('#login').fadeIn();

$(".popup-btn").click(function () {
            var target = $(this).attr("href");
            $(target).fadeIn();
 });
 
$(".popup .close").click(function () {
            $(".popup").fadeOut();
 });
 

  </script>
  
  

</body>

</html>
